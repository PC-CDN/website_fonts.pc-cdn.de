# @primer/styled-octicons

[![npm version](https://img.shields.io/npm/v/@primer/styled-octicons.svg)](https://www.npmjs.org/package/@primer/styled-octicons)

See https://primer.style/octicons/packages/styled-system
