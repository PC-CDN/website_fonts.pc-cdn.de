module Octicons
  VERSION = "16.3.1".freeze
end
