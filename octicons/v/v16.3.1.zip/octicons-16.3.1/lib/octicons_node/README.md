# @primer/octicons

[![npm version](https://img.shields.io/npm/v/@primer/octicons.svg)](https://www.npmjs.org/package/@primer/octicons)

See https://primer.style/octicons/packages/javascript